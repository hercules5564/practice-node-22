const express = require('express');
const app = express();
const PORT = 3000;

// Middleware to parse JSON bodies
app.use(express.json());

// In-memory storage for playing cards
let cards = [
    { id: 1, suit: "Hearts", value: "Ace" },
    { id: 2, suit: "Spades", value: "King" },
    { id: 3, suit: "Diamonds", value: "Queen" }
];

// Counter for generating unique IDs
let nextId = 4;

// GET /cards - Retrieve all cards
app.get('/cards', (req, res) => {
    res.status(200).json(cards);
});

// GET /cards/:id - Retrieve a specific card by ID
app.get('/cards/:id', (req, res) => {
    const cardId = parseInt(req.params.id);
    const card = cards.find(c => c.id === cardId);
    
    if (!card) {
        return res.status(404).json({ 
            error: "Card not found",
            message: `Card with ID ${cardId} does not exist` 
        });
    }
    
    res.status(200).json(card);
});

// POST /cards - Add a new card
app.post('/cards', (req, res) => {
    const { suit, value } = req.body;
    
    // Validation
    if (!suit || !value) {
        return res.status(400).json({ 
            error: "Invalid input",
            message: "Both 'suit' and 'value' are required" 
        });
    }
    
    // Valid suits and values for playing cards
    const validSuits = ["Hearts", "Diamonds", "Clubs", "Spades"];
    const validValues = ["Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King"];
    
    if (!validSuits.includes(suit)) {
        return res.status(400).json({ 
            error: "Invalid suit",
            message: `Suit must be one of: ${validSuits.join(', ')}` 
        });
    }
    
    if (!validValues.includes(value)) {
        return res.status(400).json({ 
            error: "Invalid value",
            message: `Value must be one of: ${validValues.join(', ')}` 
        });
    }
    
    // Check if card already exists
    const existingCard = cards.find(c => c.suit === suit && c.value === value);
    if (existingCard) {
        return res.status(409).json({ 
            error: "Card already exists",
            message: `${value} of ${suit} already exists in the collection` 
        });
    }
    
    const newCard = {
        id: nextId++,
        suit,
        value
    };
    
    cards.push(newCard);
    res.status(201).json(newCard);
});

// PUT /cards/:id - Update a specific card by ID
app.put('/cards/:id', (req, res) => {
    const cardId = parseInt(req.params.id);
    const { suit, value } = req.body;
    
    const cardIndex = cards.findIndex(c => c.id === cardId);
    
    if (cardIndex === -1) {
        return res.status(404).json({ 
            error: "Card not found",
            message: `Card with ID ${cardId} does not exist` 
        });
    }
    
    // Validation
    if (!suit || !value) {
        return res.status(400).json({ 
            error: "Invalid input",
            message: "Both 'suit' and 'value' are required" 
        });
    }
    
    const validSuits = ["Hearts", "Diamonds", "Clubs", "Spades"];
    const validValues = ["Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King"];
    
    if (!validSuits.includes(suit) || !validValues.includes(value)) {
        return res.status(400).json({ 
            error: "Invalid card data",
            message: "Please provide valid suit and value" 
        });
    }
    
    // Check if updated card would conflict with existing cards
    const existingCard = cards.find(c => c.suit === suit && c.value === value && c.id !== cardId);
    if (existingCard) {
        return res.status(409).json({ 
            error: "Card already exists",
            message: `${value} of ${suit} already exists in the collection` 
        });
    }
    
    cards[cardIndex] = { id: cardId, suit, value };
    res.status(200).json(cards[cardIndex]);
});

// DELETE /cards/:id - Delete a specific card by ID
app.delete('/cards/:id', (req, res) => {
    const cardId = parseInt(req.params.id);
    const cardIndex = cards.findIndex(c => c.id === cardId);
    
    if (cardIndex === -1) {
        return res.status(404).json({ 
            error: "Card not found",
            message: `Card with ID ${cardId} does not exist` 
        });
    }
    
    const deletedCard = cards[cardIndex];
    cards.splice(cardIndex, 1);
    
    res.status(200).json({
        message: `Card with ID ${cardId} removed`,
        card: deletedCard
    });
});

// GET /cards/search - Search cards by suit or value
app.get('/cards/search', (req, res) => {
    const { suit, value } = req.query;
    
    let filteredCards = cards;
    
    if (suit) {
        filteredCards = filteredCards.filter(c => 
            c.suit.toLowerCase() === suit.toLowerCase()
        );
    }
    
    if (value) {
        filteredCards = filteredCards.filter(c => 
            c.value.toLowerCase() === value.toLowerCase()
        );
    }
    
    res.status(200).json(filteredCards);
});

// GET /cards/stats - Get collection statistics
app.get('/cards/stats', (req, res) => {
    const stats = {
        totalCards: cards.length,
        cardsBySuit: {
            Hearts: cards.filter(c => c.suit === "Hearts").length,
            Diamonds: cards.filter(c => c.suit === "Diamonds").length,
            Clubs: cards.filter(c => c.suit === "Clubs").length,
            Spades: cards.filter(c => c.suit === "Spades").length
        },
        uniqueValues: [...new Set(cards.map(c => c.value))].length
    };
    
    res.status(200).json(stats);
});

// Start the server
app.listen(PORT, () => {
    console.log(`🃏 Playing Card Collection API is running on http://localhost:${PORT}`);
    console.log('\n📋 Available endpoints:');
    console.log('  GET    /cards           - Get all cards');
    console.log('  GET    /cards/:id       - Get card by ID');
    console.log('  POST   /cards           - Add new card');
    console.log('  PUT    /cards/:id       - Update card by ID');
    console.log('  DELETE /cards/:id       - Delete card by ID');
    console.log('  GET    /cards/search    - Search cards by suit or value');
    console.log('  GET    /cards/stats     - Get collection statistics');
    console.log('\n🚀 Ready to manage your card collection!');
});

module.exports = app;